#pragma once
#ifndef QUANLISINHVIEN_INDANHSACH_H
#define QUANLISINHVIEN_INDANHSACH_H

#include "SinhVien.h"
#include <string>
#include <vector>
#include "SapXep.h"

class InDanhSach {
private:
    vector<SinhVien> DanhSach;
    string titleM2 = " _____________________________________________________________________________\n"
        "|           |                 |                       |             |         |\n"
        "|  Ma Lop   |  Ma sinh vien   |      Ho va ten        |  Ngay sinh  |  DTBTL  |\n"
        "|___________|_________________|_______________________|_____________|_________|",
        midLineM2 = "|           |                 |                       |             |         |",
        endLineM2 = "|___________|_________________|_______________________|_____________|_________|";
    vector<string> printM2 = { "Quay lai.", "\n", titleM2 };
public:
    static int n;
    InDanhSach();
    void importData();
    void printData();
    string centerString(string s, int space);
    string centerString(int s, int space);
    void printListStudent();

};

vector<SinhVien> getData();
void ask();


void pressEnterInM2(int index);

#endif 