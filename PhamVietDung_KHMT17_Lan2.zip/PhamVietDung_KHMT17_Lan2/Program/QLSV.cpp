#include <iostream>
#include "sinhVien.h"
#include "menu.h"

using namespace std;

int main(int argc, char** argv) {
    Menu _menu;
    _menu.hienThi();
    return 0;
}
