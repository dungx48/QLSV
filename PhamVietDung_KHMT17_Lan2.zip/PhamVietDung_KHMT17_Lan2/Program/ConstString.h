#pragma once
#ifndef QUANLISINHVIEN_CONSTSTRING_H
#define QUANLISINHVIEN_CONSTSTRING_H

#include <string>

using namespace std;

class ConstString {
public:
    static const string nhapsai;
    static const string baotri;
};

#endif