#ifndef QUANLISINHVIEN_TOOLS_H
#define QUANLISINHVIEN_TOOLS_H

#include <iostream>
#include <Windows.h>

using namespace std;

class Tools {
    public:
        static void gotoxy(int x, int y);
        static void color(int x);
};


#endif //QUANLISINHVIEN_TOOLS_H
