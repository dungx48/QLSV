#include "ConstString.h"

const string ConstString::nhapsai = "Loi! Nhap lai: ";
const string ConstString::baotri = "Tinh nang dang duoc nang cap!\nVui long quay lai sau";

